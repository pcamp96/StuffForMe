<?php        
defined('C5_EXECUTE') or die(_("Access Denied."));
class DashboardVanillaForumsController extends Controller {
	public $helpers = array("form");
	public function view(){
		$this->set('url',config::get('vanilla_url'));
	}
	public function vanilla(){
		config::save('vanilla_url',$this->post('url'));
		$this->view();
	}
}
?>