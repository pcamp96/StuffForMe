<?php        
defined('C5_EXECUTE') or die(_("Access Denied."));	
$h = Loader::helper('concrete/interface');
$form = Loader::helper('form');?>
	<?php     echo Loader::helper('concrete/dashboard')->getDashboardPaneHeaderWrapper(t('Vanilla Forums Configuration Information'));?>
		<table class="bordered-table zebra-striped">
<?php      
echo t('You need to copy these values into the proxyconnect page in your vanilla forums install.');
echo '<br/><b>'.t('Main Site Url').'</b><br/>';
echo '<input id="url" type="text" name="url" value="'.BASE_URL.view::url('/').'" onclick="this.select()" style="width: 400px" class="ccm-input-text" readonly/><br/>';
echo '<b>'.t('Authenticate Url').'</b><br/>';
echo '<input id="url" type="text" name="url" value="'.BASE_URL.view::url('/vanilla_sso/').'" onclick="this.select()" style="width: 400px" class="ccm-input-text" readonly/><br/>';
echo '<b>'.t('Registration Url').'</b><br/>';
echo '<input id="url" type="text" name="url" value="'.BASE_URL.view::url('/register').'" onclick="this.select()" style="width: 400px" class="ccm-input-text" readonly/><br/>';
echo '<b>'.t('Sign-In Url').'</b><br/>';
echo '<input id="url" type="text" name="url" value="'.BASE_URL.view::url('/login').'?vanilla=1" onclick="this.select()" style="width: 400px" class="ccm-input-text" readonly/><br/>';
echo '<b>'.t('Sign-Out Url').'</b><br/>';
echo '<input id="url" type="text" name="url" value="'.BASE_URL.view::url('/login').'logout" onclick="this.select()" style="width: 400px" class="ccm-input-text" readonly/><br/>';
echo '<form class="form-stacked"method="post" action="'.$this->action('vanilla').'">';
echo '<br/><h2>'.t('Settings').'</h2><b>'.$form->label('theme',t('Url of vanilla forums.')).'</b>';
	echo $form->text('url',$url,array("style"=>'width: 400px'));
	echo '<input type="submit"class="btn-large primary" value="'.t('Save').'"/>';
	echo '</form>';	
?>