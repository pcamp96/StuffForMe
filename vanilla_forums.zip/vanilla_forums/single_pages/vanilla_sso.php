<?php        defined('C5_EXECUTE') or die("Access Denied."); 
	global $u;
	if ($u->isLoggedIn()) {
		$u = new User(); 
		$ui = UserInfo::getByID($u->getUserID());
		echo "UniqueID=".$u->getUserID()."\n";
		echo "Name=".$u->getUserName()."\n";
		echo "Email=".$ui->getUserEmail()."\n";
	}
 
?>