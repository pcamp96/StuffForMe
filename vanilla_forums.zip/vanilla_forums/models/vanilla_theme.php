<?php       
$v = View::getInstance();
$v->setThemeByPath('/vanilla_sso', 'vanilla_blank');