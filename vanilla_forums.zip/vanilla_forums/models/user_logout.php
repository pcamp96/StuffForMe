<?php 
defined('C5_EXECUTE') or die("Access Denied.");
	class UserLogout extends Object {
		public static function userLogoutReal(){
			setcookie('Vanilla', ' ', time() - 3600, '/', BASE_URL);
			unset($_COOKIE['Vanilla']);
		}
		public function userLogin(){
			setcookie('Vanilla', ' ', time() + 3600, '/', BASE_URL);
		}
	}
?>
