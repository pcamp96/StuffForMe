<?php 
defined('C5_EXECUTE') or die(_("Access Denied."));

class VanillaForumsPackage extends Package {

	protected $pkgHandle = 'vanilla_forums';
	protected $appVersionRequired = '5.5';
	protected $pkgVersion = '1.0.4';

	public function getPackageDescription() {
		return t("Integration with vanilla forums");
	}

	public function getPackageName() {
		return t("Vanilla Forums");
	}

	public function install() {
		//copy register
		if(!is_writable(DIR_REL.'/controllers')){
			if(file_exists(DIR_REL.'/controllers/login.php')){
				$message = t("You can't have the file register.php in root/controllers. Delete it and try again.");
				throw new Exception($message);
				exit;
			}else{
				$source = DIRNAME_PACKAGES . '/'.$this->pkgHandle.'/controllers/login.php';
				$target = DIR_BASE.'/controllers/login.php';
				if(!copy($source, $target)){
					$message=t('Could not copy login.php');
					throw new Exception($message);
					exit;
				}
			}
		}else{
			$message=t('You need to make the folder '.DIR_REL.'/controllers writable');
			throw new Exception($message);
			exit;
		}
		if(!is_writable(DIR_REL.'/single_pages')){
			if(file_exists(DIR_REL.'/single_pages/login.php')){
				$message = t("You can't have the file login.php in root/single_pages. Delete it and try again.");
				throw new Exception($message);
				exit;
			}else{
				$source = DIRNAME_PACKAGES . '/'.$this->pkgHandle.'/single_pages/login.php';
				$target = DIR_BASE.'/single_pages/login.php';
				if(!copy($source, $target)){
					$message=t('Could not copy login.php');
					throw new Exception($message);
					exit;
				}
			}
		}else{
			$message=t('You need to make the folder '.DIR_REL.'/single_pages writable');
			throw new Exception($message);
			exit;
		}
		$pkg=parent::install();
		Loader::model('single_page');
		$p1 = SinglePage::add('/vanilla_sso',$pkg);
		$p1->setAttribute(CollectionAttributeKey::getByHandle('exclude_page_list'), 1);
		$p1->setAttribute(CollectionAttributeKey::getByHandle('exclude_nav'), 1);
		$p1->setAttribute(CollectionAttributeKey::getByHandle('exclude_search_index'), 1);
		$p1->setAttribute(CollectionAttributeKey::getByHandle('exclude_sitemapxml'), 1);
       	$p1 = SinglePage::add('/dashboard/vanilla_forums/',$pkg);
        $p1->update(array('cName'=>t("Vanilla Configuration"), 'cDescription'=>t("Configure integration with vanilla forums.")));
        PageTheme::add('vanilla_blank', $pkg);
	}
	public function on_start() {
		Events::extend('on_user_logout', 'UserLogout', 'userLogoutReal', DIRNAME_PACKAGES . '/' . $this->pkgHandle . '/' . DIRNAME_MODELS . '/user_logout.php');
		Events::extend('on_user_login', 'UserLogout', 'userLogin', DIRNAME_PACKAGES . '/' . $this->pkgHandle . '/' . DIRNAME_MODELS . '/user_logout.php');
		Events::extend('on_start', 'VanillaTheme', 'theme', DIRNAME_PACKAGES . '/' . $this->pkgHandle . '/' . DIRNAME_MODELS . '/vanilla_theme.php');
	}


}
